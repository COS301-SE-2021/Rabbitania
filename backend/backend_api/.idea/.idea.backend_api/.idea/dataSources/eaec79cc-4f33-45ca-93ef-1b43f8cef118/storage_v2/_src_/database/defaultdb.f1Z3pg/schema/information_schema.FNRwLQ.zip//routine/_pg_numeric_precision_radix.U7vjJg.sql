create function _pg_numeric_precision_radix(typid oid, typmod integer) returns integer
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT
  CASE WHEN $1 IN (21, 23, 20, 700, 701) THEN 2
       WHEN $1 IN (1700) THEN 10
       ELSE null
  END
$$;

alter function _pg_numeric_precision_radix(oid, integer) owner to postgres;

